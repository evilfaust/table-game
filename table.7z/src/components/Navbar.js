import React, { useState } from "react";
import { Menu, Dropdown, Button, Drawer } from "antd";
import { MenuOutlined } from "@ant-design/icons";
// import "./Navbar.css"; // Подключите свои стили

const Navbar = () => {
  const [visible, setVisible] = useState(false);

  const showDrawer = () => {
    setVisible(true);
  };

  const closeDrawer = () => {
    setVisible(false);
  };

  const coursesMenu = (
    <Menu>
      <Menu.Item key="all">
        <a href="https://emcotech.site/index.php?id=1#projects">Все курсы</a>
      </Menu.Item>
      <Menu.Item key="vr">
        <a href="https://emcotech.site/index.php?id=4">VR/AR LAB</a>
      </Menu.Item>
      <Menu.Item key="it">
        <a href="https://emcotech.site/index.php?id=5">IT LAB</a>
      </Menu.Item>
      <Menu.Item key="english">
        <a href="https://emcotech.site/index.php?id=3">EASY ENGLISH LAB</a>
      </Menu.Item>
      <Menu.Item key="esports">
        <a href="https://emcotech.site/index.php?id=67">Киберспортивная школа</a>
      </Menu.Item>
      <Menu.Item key="korean">
        <a href="https://emcotech.site/index.php?id=82">Корейский язык (Шахтерск)</a>
      </Menu.Item>
      <Menu.Item key="club">
        <a href="https://emcotech.site/index.php?id=68">Разговорный клуб</a>
      </Menu.Item>
      <Menu.Item key="board-games">
        <a href="https://emcotech.site/index.php?id=83">Клуб настольных игр</a>
      </Menu.Item>
      <Menu.Item key="smart-kids">
        <a href="https://emcotech.site/index.php?id=30">SMART KIDS</a>
      </Menu.Item>
      <Menu.Item key="camp" disabled>
        <a href="https://emcotech.site/index.php?id=79">Летний лагерь</a>
      </Menu.Item>
      <Menu.Item key="english-uglegorsk" disabled>
        <a href="https://emcotech.site/index.php?id=38">Английский в Углегорске</a>
      </Menu.Item>
      <Menu.Item key="korean-uglegorsk" disabled>
        <a href="https://emcotech.site/index.php?id=69">Корейский язык (Углегорск)</a>
      </Menu.Item>
    </Menu>
  );

  return (
    <>
      <nav className="navbar">
        <div className="container">
          {/* Лого */}
          <a className="logo" href="https://emcotech.site">
            <img src="assets/emcotech/images/new-logo.png" style={{ height: 24 }} alt="EMCO.TECH" />
          </a>

          {/* Кнопка для мобильного меню */}
          <Button type="text" className="menu-button" onClick={showDrawer}>
            <MenuOutlined style={{ fontSize: 24, color: "#fff" }} />
          </Button>

          {/* Меню для десктопа */}
          <Menu mode="horizontal" className="desktop-menu">
            <Menu.Item key="home">
              <a href="https://emcotech.site/index.php?id=1#home">Главная</a>
            </Menu.Item>
            <Menu.Item key="about">
              <a href="https://emcotech.site/index.php?id=1#about">О нас</a>
            </Menu.Item>
            <Menu.Item key="courses">
              <Dropdown overlay={coursesMenu}>
                <a onClick={(e) => e.preventDefault()}>Курсы</a>
              </Dropdown>
            </Menu.Item>
            <Menu.Item key="esports">
              <a href="https://emcotech.site/index.php?id=39">Киберспорт</a>
            </Menu.Item>
            <Menu.Item key="schedule">
              <a href="https://emcotech.site/index.php?id=2">Расписание</a>
            </Menu.Item>
            <Menu.Item key="prices">
              <a href="https://emcotech.site/index.php?id=7">Цены</a>
            </Menu.Item>
            <Menu.Item key="events">
              <a href="https://emcotech.site/index.php?id=14">События</a>
            </Menu.Item>
            <Menu.Item key="signup">
              {/* <a onClick={() => WdgMoyklass["01MIgPXlkQZxD74OHYK1myqCmOgEJKo1peQK"].loadFormByModal()}> */}
                Запись
              {/* </a> */}
            </Menu.Item>
          </Menu>
        </div>
      </nav>

      {/* Drawer для мобильного меню */}
      <Drawer
        title="Меню"
        placement="right"
        closable={true}
        onClose={closeDrawer}
        visible={visible}
      >
        <Menu mode="vertical">
          <Menu.Item key="home">
            <a href="https://emcotech.site/index.php?id=1#home">Главная</a>
          </Menu.Item>
          <Menu.Item key="about">
            <a href="https://emcotech.site/index.php?id=1#about">О нас</a>
          </Menu.Item>
          <Menu.SubMenu key="courses" title="Курсы">
            {coursesMenu}
          </Menu.SubMenu>
          <Menu.Item key="esports">
            <a href="https://emcotech.site/index.php?id=39">Киберспорт</a>
          </Menu.Item>
          <Menu.Item key="schedule">
            <a href="https://emcotech.site/index.php?id=2">Расписание</a>
          </Menu.Item>
          <Menu.Item key="prices">
            <a href="https://emcotech.site/index.php?id=7">Цены</a>
          </Menu.Item>
          <Menu.Item key="events">
            <a href="https://emcotech.site/index.php?id=14">События</a>
          </Menu.Item>
          <Menu.Item key="signup">
            {/* <a onClick={() => WdgMoyklass["01MIgPXlkQZxD74OHYK1myqCmOgEJKo1peQK"].loadFormByModal()}> */}
              Запись
            {/* </a> */}
          </Menu.Item>
        </Menu>
      </Drawer>
    </>
  );
};

export default Navbar;
